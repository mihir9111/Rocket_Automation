package framework.input;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import base.BaseSuite;

/**
 * 
 * This class is used to access the framework/global configurations from
 * config.properties file & developer configurations from
 * ./libs/configs/devConfig.properties
 * 
 * @author bhavikt
 *
 */

public class Configuration {

	// for getting the file
	static InputStream input = null;

	static Properties props = new Properties();
	static String configPath = "config.properties";

	// for dev config reading
	static Properties devProps = new Properties();
	static String devConfigPath = "./libs/configs/devConfig.properties";

	static {
		try {
			// for config properties
			input = new FileInputStream(configPath);
			// load a properties file
			props.load(input);

			// for dev config properties
			input.close();
			input = new FileInputStream(devConfigPath);
			devProps.load(input);

		} catch (IOException ex) {
			String expMessage = ex.getMessage();
			if (expMessage.contains("devConfig") && expMessage.contains("The system cannot find the file specified"))
				System.out.println("Developer config is not provided at path - " + devConfigPath);
			else if (expMessage.contains("config") && expMessage.contains("The system cannot find the file specified"))
				System.out.println("config.property file is not present at root of the project");
			else
				ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * To get the property from the config.property(should be present at project root)
	 * 
	 * @param propertyName
	 * 
	 * @return String
	 */
	public static String getConfigProp(String propertyName) {
		return getProperty(props, propertyName);
	}

	/**
	 * To get the property from the devConfig.property(should be present at './libs/configs'
	 * path)
	 * 
	 * @param propertyName
	 * 
	 * @return String
	 */
	public static String getDevConfigProp(String propertyName) {
		return getProperty(devProps, propertyName);
	}

	/**
	 * Reusable method to read the given propertyName from the given props object
	 * 
	 * @param propsObject  Properties object
	 * @param propertyName String
	 * 
	 * @return String
	 */
	private static String getProperty(Properties propsObject, String propertyName) {
		String value = null;
		try {
			value = propsObject.getProperty(propertyName).trim();
		} catch (Exception e) {
			String logMsg = "Property not found with key - " + propertyName;
			if (BaseSuite.log != null)
				BaseSuite.log.warn(logMsg);
			else
				System.out.println(logMsg);
		}
		return value;
	}

	/**
	 * @deprecated
	 * @param propertyName
	 * @return
	 */
	public static String getProperty(String propertyName) {
		String value = null;
		try {
			value = props.getProperty(propertyName).trim();
		} catch (Exception e) {
			String logMsg = "Property not found with key - " + propertyName;
			if (BaseSuite.log != null)
				BaseSuite.log.warn(logMsg);
			else
				System.out.println(logMsg);
		}
		return value;
	}

}
