package framework.uploadreport;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;

import base.BaseSuite;
import framework.Cyfer;
import framework.input.Configuration;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.CompressionLevel;
import net.lingala.zip4j.model.enums.CompressionMethod;

public class UploadReport {

	/**
	 * To create report zip > upload it to server and delete the zip
	 * 
	 * @param apiURL
	 *        - API URL in the format
	 *        'http://host:port/endpoint'
	 * 
	 * @param serverFolderPath
	 *        - Folder hierarchy in the reports folder on
	 *        server
	 * 
	 * @param reportFolderPath
	 *        - Path to zip file to be uploaded
	 * 
	 * @return boolean
	 */
	public boolean uploadReportToServer(String apiURL, String serverFolderPath, String reportFolderPath) {

		boolean isUploaded = false;

		// zip file path
		String zipFilePath = reportFolderPath + ".zip";

		// create & upload the zip
		if (createZipFile(reportFolderPath, zipFilePath) && uploadZipFile(apiURL, serverFolderPath, zipFilePath)) {
			// delete
			deleteZipFile(zipFilePath);

			isUploaded = true;
		}

		return isUploaded;
	}

	/**
	 * Uploads the zip file from the local machine to the given folder on the server
	 * using multipart POST request.
	 * 
	 * @param apiURL
	 *        - API URL in the format
	 *        'http://host:port/endpoint'
	 * @param serverFolderPath
	 *        - Folder hierarchy in the reports folder on
	 *        server
	 * @param zipFilePath
	 *        - Path to zip file to be uploaded
	 * 
	 * 
	 * @return boolean
	 * 
	 */
	private boolean uploadZipFile(String apiURL, String serverFolderPath, String zipFilePath) {

		boolean isUploaded = false;

		try {
			BaseSuite.log.debug("Started uploading the report");

			// Initiate HttpClient object
			HttpClient httpclient = HttpClientBuilder.create().build();

			// Initiate HttpPost object with apiURL in the format
			// 'http://host:port/endpoint'
			HttpPost httpPost = new HttpPost(apiURL);

			// Initiate MultiPartEntity object using
			MultipartEntity reqEntity = new MultipartEntity();

			// Add parts for zip file and foldername to MultiPartEntity object and set it to
			// request
			reqEntity.addPart("file", new FileBody(new File(zipFilePath), "application/x-zip-compressed"));
			reqEntity.addPart("reportDirectory", new StringBody(serverFolderPath));
			reqEntity.addPart("userID", new StringBody(System.getProperty("user.name")));
			httpPost.setEntity(reqEntity);

			isUploaded = sendRequest(httpPost);

			if (isUploaded)
				BaseSuite.log.debug("Successfully uploaded the report");
			else
				BaseSuite.log.debug("Report not uploaded");

		} catch (Exception e) {
			BaseSuite.log.trace("Failed while uploading the report - " + e);
		}

		return isUploaded;

	}

	/**
	 * 
	 * Send the request
	 * 
	 * @param httpPost
	 *        request object
	 * @return request successful or not
	 */
	public boolean sendRequest(HttpPost httpPost) {

		boolean isResponseSend = false;

		try {
			BaseSuite.log.debug("Started creating request");

			// attaching the certificate
			System.setProperty("javax.net.ssl.trustStore", Configuration.getConfigProp("certificatesTrustStorePath"));

			HttpClient httpclient = HttpClientBuilder.create().build();

			httpPost.setHeader("Authorization", "Bearer " + getToken());

			// Execute POST request and get the response.
			HttpResponse response = httpclient.execute(httpPost);

			if (!response.getStatusLine().toString().contains("200")) {

				generateToken();

				// add token again
				httpPost.setHeader("Authorization", "Bearer " + getToken());

				// Execute POST request and get the response.
				response = httpclient.execute(httpPost);
			}

			// Response status for reference
			BaseSuite.log.debug(response.getStatusLine().toString());

			isResponseSend = response.getStatusLine().toString().contains("200");

			BaseSuite.log.debug("Ended creating request");
		} catch (Exception e) {
			BaseSuite.log.error("Failed to send the requrest - ", e);
		}

		return isResponseSend;
	}

	/**
	 * Read the token from txt file from configuration accessTokenFilePath
	 * 
	 * @return token string
	 */
	public static String getToken() {
		String token = "";

		BaseSuite.log.debug("Started getting access token");

		try {
			if (!new File(Configuration.getConfigProp("accessTokenFilePath")).exists())
				generateToken();
			token = new String(Files.readAllBytes(Paths.get(Configuration.getConfigProp("accessTokenFilePath"))));
		} catch (IOException e) {
			BaseSuite.log.error("Failed to get Token from file", e);
		}

		BaseSuite.log.debug("Ended getting access token");

		return token;
	}

	/**
	 * Generate the token and store to the access_token file in accessTokenFilePath
	 * directory
	 */
	public static void generateToken() {
		try {
			BaseSuite.log.debug("Started generating access token");

			// attaching the certificate
			System.setProperty("javax.net.ssl.trustStore", Configuration.getConfigProp("certificatesTrustStorePath"));

			// create json object for request
			JSONObject jsonObj = new JSONObject();

			// check if 'key' available to encrypt the password
			String encryptionKey = Configuration.getConfigProp("key");
			String password;
			if (encryptionKey != null && !encryptionKey.trim().isEmpty())
				password = Cyfer.decrypt(Configuration.getConfigProp("tokenPassword"), encryptionKey);
			else
				password = Configuration.getConfigProp("tokenPassword");

			jsonObj.put("username", Configuration.getConfigProp("tokenUserName"));
			jsonObj.put("password", password);

			// create entity
			StringEntity entity = new StringEntity(jsonObj.toString(), ContentType.APPLICATION_JSON);

			// send the request
			HttpClient httpClient = HttpClientBuilder.create().build();
			HttpPost request = new HttpPost(Configuration.getConfigProp("axesTokenGenerateAPI"));
			request.setEntity(entity);

			// set the header
			request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");

			// fetch the response
			HttpResponse response = httpClient.execute(request);
			String content = EntityUtils.toString(response.getEntity());
			BaseSuite.log.debug("First calling of generating token API response - " + content);

			// if response is not with 200 status resend request
			if (!response.getStatusLine().toString().contains("200")) {
				BaseSuite.log.debug("First request is not with status 200, calling request again");
				response = httpClient.execute(request);
				content = EntityUtils.toString(response.getEntity());
				BaseSuite.log.debug("First calling of generating token API response - " + content);
			}

			// store access token
			String encodedToken = "";
			if (response.getStatusLine().toString().contains("200")) {
				BaseSuite.log.debug("Generate token API responce before storing to file - " + content);

				// create the json object of content and fetch the token from it
				org.json.JSONObject jsonob = new org.json.JSONObject(content);

				encodedToken = jsonob.get("accessToken").toString();
				BaseSuite.log.debug("Access token generated successfully");
			}

			// write the token to the file
			FileWriter myWriter = new FileWriter(Configuration.getConfigProp("accessTokenFilePath"));
			myWriter.write(encodedToken);
			myWriter.close();

			BaseSuite.log.debug("Ended generating access token");
		} catch (IOException e) {
			BaseSuite.log.error("Failed while writing the token to file" + e);
		} catch (Exception e) {
			BaseSuite.log.error("Exception occured in generating token from API - ", e);
		}
	}

	/**
	 * Creates new zip file from the given folder.
	 * 
	 * @param folderPath
	 *        - Path to the folder to be archived
	 * @param zipPath
	 *        - Path where the zip file is to be placed
	 * 
	 * @return boolean
	 */
	private boolean createZipFile(String folderPath, String zipPath) {

		boolean isZipped = false;

		// Initiate ZipFile object with the path/name of the zip file.
		try (ZipFile zipFile = new ZipFile(zipPath);) {
			BaseSuite.log.debug("Started creating the report zip");

			// Initiate Zip Parameters which define various properties such
			// as compression method, etc.
			ZipParameters parameters = new ZipParameters();

			// set compression method to store compression
			parameters.setCompressionMethod(CompressionMethod.DEFLATE);

			// Set the compression level
			parameters.setCompressionLevel(CompressionLevel.FAST);

			// Add folder to the zip file
			zipFile.addFolder(new File(folderPath), parameters);

			isZipped = true;

			BaseSuite.log.debug("Successfully created the report zip");
		} catch (Exception e) {
			BaseSuite.log.trace("Failed while creating zip of folder - " + e);
		}

		return isZipped;
	}

	/**
	 * To delete the zip file path given
	 * 
	 * @param zipPath
	 */
	private void deleteZipFile(String zipPath) {

		try {
			BaseSuite.log.debug("Started deleting the zip in local at path - " + zipPath);

			// Initiate ZipFile object with the path/name of the zip file.
			File zipFile = new File(zipPath);

			// Initiate Zip Parameters which define various
			zipFile.delete();

			BaseSuite.log.debug("Successfully deleted the report zip");
		} catch (Exception e) {
			BaseSuite.log.trace("Failed to delete zip at - " + zipPath + " Exception - " + e);
		}
	}

}
